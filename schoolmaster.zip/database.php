<?php
$url='sdb-58.hosting.stackcp.net';
$username='student25-35303137bd4b';
$password='ua92-studentAc';
$conn=mysqli_connect($url,$username,$password,"student25-35303137bd4b");
if(!$conn){
 die('Could not Connect My Sql:' .mysql_error());
}
?>